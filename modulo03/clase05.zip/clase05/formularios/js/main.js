// recomendacion
$(function(){
	$("#grabarDatos").click(function(){
		let inp_nombre=$("#inp-nombres").val();
		let persona={
			nombre:inp_nombre
		}
		agregarPersona(persona);
		
		listarPersonas();
	})	

})
var listadoPersonas=[];
function agregarPersona(objeto){
	listadoPersonas.push(objeto);
}

function listarPersonas(){
	$(".listadoPersonas").html("");
	listadoPersonas.forEach(function(elemento,indice){
		console.log(indice);
		console.log(elemento)
		$(".listadoPersonas").append(`<article class="pt-2">
						<h2 class="h5 float-left">`+elemento.nombre+`</h2>
						<button class="btn btn-info float-right">Ver Detalle</button>
						<div class="clearfix"></div>
					</article>`)

	})
}

/*
// cuando todo el contenido este cargado
$(window).load(function(){



})

// cuando solo se carge el DOM 
$(document).ready(function(){

})*/
