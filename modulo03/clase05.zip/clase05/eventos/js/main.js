// varibales de tipo let y var
// let=local var=global